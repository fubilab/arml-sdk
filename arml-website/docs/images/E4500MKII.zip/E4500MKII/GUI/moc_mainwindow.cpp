/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../GUI/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[132];
    char stringdata0[5094];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 12), // "timerTimeout"
QT_MOC_LITERAL(2, 24, 0), // ""
QT_MOC_LITERAL(3, 25, 32), // "on_checkBox_updateStatus_toggled"
QT_MOC_LITERAL(4, 58, 7), // "checked"
QT_MOC_LITERAL(5, 66, 29), // "on_pushButton_Connect_clicked"
QT_MOC_LITERAL(6, 96, 27), // "on_pushButton_Reset_clicked"
QT_MOC_LITERAL(7, 124, 32), // "on_radioButton_VideoMode_clicked"
QT_MOC_LITERAL(8, 157, 29), // "on_radioButton_SLMode_clicked"
QT_MOC_LITERAL(9, 187, 40), // "on_radioButton_VariableExpSLM..."
QT_MOC_LITERAL(10, 228, 34), // "on_radioButton_StandbyMode_cl..."
QT_MOC_LITERAL(11, 263, 41), // "on_pushButton_GetLEDConfigura..."
QT_MOC_LITERAL(12, 305, 41), // "on_pushButton_SetLEDConfigura..."
QT_MOC_LITERAL(13, 347, 29), // "on_pushButton_GetFlip_clicked"
QT_MOC_LITERAL(14, 377, 29), // "on_pushButton_SetFlip_clicked"
QT_MOC_LITERAL(15, 407, 39), // "on_radioButton_ColorDisplayAu..."
QT_MOC_LITERAL(16, 447, 41), // "on_radioButton_ColorDisplayMa..."
QT_MOC_LITERAL(17, 489, 35), // "on_pushButton_ApplySolution_c..."
QT_MOC_LITERAL(18, 525, 34), // "on_pushButton_SaveSolution_cl..."
QT_MOC_LITERAL(19, 560, 42), // "on_pushButton_ApplyDefaultSol..."
QT_MOC_LITERAL(20, 603, 35), // "on_pushButton_SetPortSource_c..."
QT_MOC_LITERAL(21, 639, 35), // "on_pushButton_GetPortSource_c..."
QT_MOC_LITERAL(22, 675, 47), // "on_comboBox_InputSourceList_c..."
QT_MOC_LITERAL(23, 723, 5), // "index"
QT_MOC_LITERAL(24, 729, 33), // "on_pushButton_SetPortSwap_cli..."
QT_MOC_LITERAL(25, 763, 33), // "on_pushButton_GetPortSwap_cli..."
QT_MOC_LITERAL(26, 797, 40), // "on_pushButton_SetPortPixelFor..."
QT_MOC_LITERAL(27, 838, 40), // "on_pushButton_GetPortPixelFor..."
QT_MOC_LITERAL(28, 879, 34), // "on_pushButton_SetPortClock_cl..."
QT_MOC_LITERAL(29, 914, 34), // "on_pushButton_GetPortClock_cl..."
QT_MOC_LITERAL(30, 949, 32), // "on_pushButton_SetFPDMode_clicked"
QT_MOC_LITERAL(31, 982, 32), // "on_pushButton_GetFPDMode_clicked"
QT_MOC_LITERAL(32, 1015, 33), // "on_pushButton_SetTPGColor_cli..."
QT_MOC_LITERAL(33, 1049, 33), // "on_pushButton_GetTPGColor_cli..."
QT_MOC_LITERAL(34, 1083, 45), // "on_pushButton_SetDisplayConfi..."
QT_MOC_LITERAL(35, 1129, 45), // "on_pushButton_GetDisplayConfi..."
QT_MOC_LITERAL(36, 1175, 40), // "on_pushButton_GetVideoSingalI..."
QT_MOC_LITERAL(37, 1216, 40), // "on_radioButton_PatSeqSrcFrmFl..."
QT_MOC_LITERAL(38, 1257, 44), // "on_radioButton_PatSeqSrcFrmVi..."
QT_MOC_LITERAL(39, 1302, 43), // "on_radioButton_PatSeqTrigType..."
QT_MOC_LITERAL(40, 1346, 42), // "on_radioButton_PatSeqTrigType..."
QT_MOC_LITERAL(41, 1389, 43), // "on_spinBox_PatSeqFrameImgInde..."
QT_MOC_LITERAL(42, 1433, 4), // "arg1"
QT_MOC_LITERAL(43, 1438, 52), // "on_comboBox_PatSeqPatBitDepth..."
QT_MOC_LITERAL(44, 1491, 41), // "on_listWidget_PatSeqBitPlanes..."
QT_MOC_LITERAL(45, 1533, 16), // "QListWidgetItem*"
QT_MOC_LITERAL(46, 1550, 4), // "item"
QT_MOC_LITERAL(47, 1555, 39), // "on_pushButton_PatSeqAddPatToL..."
QT_MOC_LITERAL(48, 1595, 50), // "on_listWidget_PatSeqLUT_custo..."
QT_MOC_LITERAL(49, 1646, 3), // "pos"
QT_MOC_LITERAL(50, 1650, 35), // "on_pushButton_PatSeqSendLUT_c..."
QT_MOC_LITERAL(51, 1686, 40), // "on_pushButton_PatSeqReadLUTFr..."
QT_MOC_LITERAL(52, 1727, 42), // "on_pushButton_PatSeqClearLUTF..."
QT_MOC_LITERAL(53, 1770, 46), // "on_radioButton_VarExpPatSeqSr..."
QT_MOC_LITERAL(54, 1817, 50), // "on_radioButton_VarExpPatSeqSr..."
QT_MOC_LITERAL(55, 1868, 49), // "on_radioButton_VarExpPatSeqTr..."
QT_MOC_LITERAL(56, 1918, 48), // "on_radioButton_VarExpPatSeqTr..."
QT_MOC_LITERAL(57, 1967, 49), // "on_spinBox_VarExpPatSeqFrameI..."
QT_MOC_LITERAL(58, 2017, 58), // "on_comboBox_VarExpPatSeqPatBi..."
QT_MOC_LITERAL(59, 2076, 47), // "on_listWidget_VarExpPatSeqBit..."
QT_MOC_LITERAL(60, 2124, 45), // "on_pushButton_VarExpPatSeqAdd..."
QT_MOC_LITERAL(61, 2170, 56), // "on_listWidget_VarExpPatSeqLUT..."
QT_MOC_LITERAL(62, 2227, 41), // "on_pushButton_VarExpPatSeqSen..."
QT_MOC_LITERAL(63, 2269, 46), // "on_pushButton_VarExpPatSeqRea..."
QT_MOC_LITERAL(64, 2316, 48), // "on_pushButton_VarExpPatSeqCle..."
QT_MOC_LITERAL(65, 2365, 36), // "on_pushButton_ValidatePatSeq_..."
QT_MOC_LITERAL(66, 2402, 37), // "on_pushButton_PatSeqCtrlStart..."
QT_MOC_LITERAL(67, 2440, 37), // "on_pushButton_PatSeqCtrlPause..."
QT_MOC_LITERAL(68, 2478, 36), // "on_pushButton_PatSeqCtrlStop_..."
QT_MOC_LITERAL(69, 2515, 46), // "on_checkBox_PatSeqCtrlGlobalD..."
QT_MOC_LITERAL(70, 2562, 42), // "on_pushButton_GetImgLoadTimin..."
QT_MOC_LITERAL(71, 2605, 35), // "on_pushButton_SetTrigConfig_c..."
QT_MOC_LITERAL(72, 2641, 35), // "on_pushButton_GetTrigConfig_c..."
QT_MOC_LITERAL(73, 2677, 31), // "on_spinBox_TrigIn1_valueChanged"
QT_MOC_LITERAL(74, 2709, 36), // "on_spinBox_Trig1OutRDly_value..."
QT_MOC_LITERAL(75, 2746, 36), // "on_spinBox_Trig1OutFDly_value..."
QT_MOC_LITERAL(76, 2783, 36), // "on_spinBox_Trig2OutRDly_value..."
QT_MOC_LITERAL(77, 2820, 40), // "on_horizontalSlider_TrigIn1_v..."
QT_MOC_LITERAL(78, 2861, 5), // "value"
QT_MOC_LITERAL(79, 2867, 45), // "on_horizontalSlider_Trig1OutR..."
QT_MOC_LITERAL(80, 2913, 45), // "on_horizontalSlider_Trig1OutF..."
QT_MOC_LITERAL(81, 2959, 45), // "on_horizontalSlider_Trig2OutR..."
QT_MOC_LITERAL(82, 3005, 45), // "on_spinBox_LedDlyCtrlRedREdge..."
QT_MOC_LITERAL(83, 3051, 54), // "on_horizontalSlider_LedDlyCtr..."
QT_MOC_LITERAL(84, 3106, 45), // "on_spinBox_LedDlyCtrlRedFEdge..."
QT_MOC_LITERAL(85, 3152, 54), // "on_horizontalSlider_LedDlyCtr..."
QT_MOC_LITERAL(86, 3207, 47), // "on_spinBox_LedDlyCtrlGreenREd..."
QT_MOC_LITERAL(87, 3255, 56), // "on_horizontalSlider_LedDlyCtr..."
QT_MOC_LITERAL(88, 3312, 47), // "on_spinBox_LedDlyCtrlGreenFEd..."
QT_MOC_LITERAL(89, 3360, 56), // "on_horizontalSlider_LedDlyCtr..."
QT_MOC_LITERAL(90, 3417, 46), // "on_spinBox_LedDlyCtrlBlueREdg..."
QT_MOC_LITERAL(91, 3464, 55), // "on_horizontalSlider_LedDlyCtr..."
QT_MOC_LITERAL(92, 3520, 46), // "on_spinBox_LedDlyCtrlBlueFEdg..."
QT_MOC_LITERAL(93, 3567, 55), // "on_horizontalSlider_LedDlyCtr..."
QT_MOC_LITERAL(94, 3623, 41), // "on_pushButton_GetLEDDlyCtrlCo..."
QT_MOC_LITERAL(95, 3665, 41), // "on_pushButton_SetLedDlyCtrlCo..."
QT_MOC_LITERAL(96, 3707, 34), // "on_pushButton_SetPWMConfig_cl..."
QT_MOC_LITERAL(97, 3742, 34), // "on_pushButton_GetPWMConfig_cl..."
QT_MOC_LITERAL(98, 3777, 37), // "on_pushButton_SetPWMCapConfig..."
QT_MOC_LITERAL(99, 3815, 37), // "on_pushButton_GetPWMCapConfig..."
QT_MOC_LITERAL(100, 3853, 32), // "on_pushButton_PWMCapRead_clicked"
QT_MOC_LITERAL(101, 3886, 32), // "on_pushBox_SetGPIOConfig_clicked"
QT_MOC_LITERAL(102, 3919, 32), // "on_pushBox_GetGPIOConfig_clicked"
QT_MOC_LITERAL(103, 3952, 29), // "on_spinBox_GpClk_valueChanged"
QT_MOC_LITERAL(104, 3982, 30), // "on_pushButton_SetGpClk_clicked"
QT_MOC_LITERAL(105, 4013, 30), // "on_pushButton_GetGpClk_clicked"
QT_MOC_LITERAL(106, 4044, 32), // "on_checkBox_GPIOEnAltFun_toggled"
QT_MOC_LITERAL(107, 4077, 30), // "on_pushButton_i2cWrite_clicked"
QT_MOC_LITERAL(108, 4108, 29), // "on_pushButton_i2cRead_clicked"
QT_MOC_LITERAL(109, 4138, 42), // "on_pushButton_CreaImgSelectBM..."
QT_MOC_LITERAL(110, 4181, 47), // "on_pushButton_CreaImgSelectDe..."
QT_MOC_LITERAL(111, 4229, 49), // "on_pushButton_CreaImgClearOut..."
QT_MOC_LITERAL(112, 4279, 41), // "on_pushButton_CreaImgAddToOut..."
QT_MOC_LITERAL(113, 4321, 51), // "on_comboBox_CreaImgFileBitDep..."
QT_MOC_LITERAL(114, 4373, 47), // "on_lineEdit_CreaImgOutputBmpF..."
QT_MOC_LITERAL(115, 4421, 35), // "on_pushButton_FWSelectFWBin_c..."
QT_MOC_LITERAL(116, 4457, 38), // "on_pushButton_FWAddSplashImag..."
QT_MOC_LITERAL(117, 4496, 41), // "on_pushButton_FWRemoveSplashI..."
QT_MOC_LITERAL(118, 4538, 50), // "on_comboBox_FWSplashImageInde..."
QT_MOC_LITERAL(119, 4589, 41), // "on_pushButton_FWChangeSplashI..."
QT_MOC_LITERAL(120, 4631, 37), // "on_pushButton_FWSelectIniFile..."
QT_MOC_LITERAL(121, 4669, 39), // "on_pushButton_FWClearSelIniFi..."
QT_MOC_LITERAL(122, 4709, 34), // "on_pushButton_FWClearFWTag_cl..."
QT_MOC_LITERAL(123, 4744, 38), // "on_radioButton_FWIllumSelColo..."
QT_MOC_LITERAL(124, 4783, 37), // "on_radioButton_FWIllumSelMono..."
QT_MOC_LITERAL(125, 4821, 39), // "on_checkBox_FWIllumSelMonoRed..."
QT_MOC_LITERAL(126, 4861, 41), // "on_checkBox_FWIllumSelMonoGre..."
QT_MOC_LITERAL(127, 4903, 40), // "on_checkBox_FWIllumSelMonoBlu..."
QT_MOC_LITERAL(128, 4944, 41), // "on_pushButton_FWSplashImageUp..."
QT_MOC_LITERAL(129, 4986, 41), // "on_pushButton_FWBuildNewFrmwI..."
QT_MOC_LITERAL(130, 5028, 34), // "on_pushButton_FWFileSelect_cl..."
QT_MOC_LITERAL(131, 5063, 30) // "on_pushButton_FWUpload_clicked"

    },
    "MainWindow\0timerTimeout\0\0"
    "on_checkBox_updateStatus_toggled\0"
    "checked\0on_pushButton_Connect_clicked\0"
    "on_pushButton_Reset_clicked\0"
    "on_radioButton_VideoMode_clicked\0"
    "on_radioButton_SLMode_clicked\0"
    "on_radioButton_VariableExpSLMode_clicked\0"
    "on_radioButton_StandbyMode_clicked\0"
    "on_pushButton_GetLEDConfiguration_clicked\0"
    "on_pushButton_SetLEDConfiguration_clicked\0"
    "on_pushButton_GetFlip_clicked\0"
    "on_pushButton_SetFlip_clicked\0"
    "on_radioButton_ColorDisplayAuto_clicked\0"
    "on_radioButton_ColorDisplayManual_clicked\0"
    "on_pushButton_ApplySolution_clicked\0"
    "on_pushButton_SaveSolution_clicked\0"
    "on_pushButton_ApplyDefaultSolution_clicked\0"
    "on_pushButton_SetPortSource_clicked\0"
    "on_pushButton_GetPortSource_clicked\0"
    "on_comboBox_InputSourceList_currentIndexChanged\0"
    "index\0on_pushButton_SetPortSwap_clicked\0"
    "on_pushButton_GetPortSwap_clicked\0"
    "on_pushButton_SetPortPixelFormat_clicked\0"
    "on_pushButton_GetPortPixelFormat_clicked\0"
    "on_pushButton_SetPortClock_clicked\0"
    "on_pushButton_GetPortClock_clicked\0"
    "on_pushButton_SetFPDMode_clicked\0"
    "on_pushButton_GetFPDMode_clicked\0"
    "on_pushButton_SetTPGColor_clicked\0"
    "on_pushButton_GetTPGColor_clicked\0"
    "on_pushButton_SetDisplayConfiguration_clicked\0"
    "on_pushButton_GetDisplayConfiguration_clicked\0"
    "on_pushButton_GetVideoSingalInfo_clicked\0"
    "on_radioButton_PatSeqSrcFrmFlash_clicked\0"
    "on_radioButton_PatSeqSrcFrmVideoPort_clicked\0"
    "on_radioButton_PatSeqTrigTypeIntExt_clicked\0"
    "on_radioButton_PatSeqTrigTypeVSync_clicked\0"
    "on_spinBox_PatSeqFrameImgIndex_valueChanged\0"
    "arg1\0on_comboBox_PatSeqPatBitDepthSel_currentIndexChanged\0"
    "on_listWidget_PatSeqBitPlanes_itemClicked\0"
    "QListWidgetItem*\0item\0"
    "on_pushButton_PatSeqAddPatToLut_clicked\0"
    "on_listWidget_PatSeqLUT_customContextMenuRequested\0"
    "pos\0on_pushButton_PatSeqSendLUT_clicked\0"
    "on_pushButton_PatSeqReadLUTFrmHW_clicked\0"
    "on_pushButton_PatSeqClearLUTFrmGUI_clicked\0"
    "on_radioButton_VarExpPatSeqSrcFrmFlash_clicked\0"
    "on_radioButton_VarExpPatSeqSrcFrmVideoPort_clicked\0"
    "on_radioButton_VarExpPatSeqTrigTypeIntExt_clicked\0"
    "on_radioButton_VarExpPatSeqTrigTypeVSync_clicked\0"
    "on_spinBox_VarExpPatSeqFrameImgIndex_valueChanged\0"
    "on_comboBox_VarExpPatSeqPatBitDepthSel_currentIndexChanged\0"
    "on_listWidget_VarExpPatSeqBitPlanes_itemClicked\0"
    "on_pushButton_VarExpPatSeqAddPatToLut_clicked\0"
    "on_listWidget_VarExpPatSeqLUT_customContextMenuRequested\0"
    "on_pushButton_VarExpPatSeqSendLUT_clicked\0"
    "on_pushButton_VarExpPatSeqReadLUTFrmHW_clicked\0"
    "on_pushButton_VarExpPatSeqClearLUTFrmGUI_clicked\0"
    "on_pushButton_ValidatePatSeq_clicked\0"
    "on_pushButton_PatSeqCtrlStart_clicked\0"
    "on_pushButton_PatSeqCtrlPause_clicked\0"
    "on_pushButton_PatSeqCtrlStop_clicked\0"
    "on_checkBox_PatSeqCtrlGlobalDataInvert_toggled\0"
    "on_pushButton_GetImgLoadTimingInfo_clicked\0"
    "on_pushButton_SetTrigConfig_clicked\0"
    "on_pushButton_GetTrigConfig_clicked\0"
    "on_spinBox_TrigIn1_valueChanged\0"
    "on_spinBox_Trig1OutRDly_valueChanged\0"
    "on_spinBox_Trig1OutFDly_valueChanged\0"
    "on_spinBox_Trig2OutRDly_valueChanged\0"
    "on_horizontalSlider_TrigIn1_valueChanged\0"
    "value\0on_horizontalSlider_Trig1OutRDly_valueChanged\0"
    "on_horizontalSlider_Trig1OutFDly_valueChanged\0"
    "on_horizontalSlider_Trig2OutRDly_valueChanged\0"
    "on_spinBox_LedDlyCtrlRedREdgeDly_valueChanged\0"
    "on_horizontalSlider_LedDlyCtrlRedREdgeDly_valueChanged\0"
    "on_spinBox_LedDlyCtrlRedFEdgeDly_valueChanged\0"
    "on_horizontalSlider_LedDlyCtrlRedFEdgeDly_valueChanged\0"
    "on_spinBox_LedDlyCtrlGreenREdgeDly_valueChanged\0"
    "on_horizontalSlider_LedDlyCtrlGreenREdgeDly_valueChanged\0"
    "on_spinBox_LedDlyCtrlGreenFEdgeDly_valueChanged\0"
    "on_horizontalSlider_LedDlyCtrlGreenFEdgeDly_valueChanged\0"
    "on_spinBox_LedDlyCtrlBlueREdgeDly_valueChanged\0"
    "on_horizontalSlider_LedDlyCtrlBlueREdgeDly_valueChanged\0"
    "on_spinBox_LedDlyCtrlBlueFEdgeDly_valueChanged\0"
    "on_horizontalSlider_LedDlyCtrlBlueFEdgeDly_valueChanged\0"
    "on_pushButton_GetLEDDlyCtrlConfig_clicked\0"
    "on_pushButton_SetLedDlyCtrlConfig_clicked\0"
    "on_pushButton_SetPWMConfig_clicked\0"
    "on_pushButton_GetPWMConfig_clicked\0"
    "on_pushButton_SetPWMCapConfig_clicked\0"
    "on_pushButton_GetPWMCapConfig_clicked\0"
    "on_pushButton_PWMCapRead_clicked\0"
    "on_pushBox_SetGPIOConfig_clicked\0"
    "on_pushBox_GetGPIOConfig_clicked\0"
    "on_spinBox_GpClk_valueChanged\0"
    "on_pushButton_SetGpClk_clicked\0"
    "on_pushButton_GetGpClk_clicked\0"
    "on_checkBox_GPIOEnAltFun_toggled\0"
    "on_pushButton_i2cWrite_clicked\0"
    "on_pushButton_i2cRead_clicked\0"
    "on_pushButton_CreaImgSelectBMPFile_clicked\0"
    "on_pushButton_CreaImgSelectDestFileName_clicked\0"
    "on_pushButton_CreaImgClearOutFileContents_clicked\0"
    "on_pushButton_CreaImgAddToOutFile_clicked\0"
    "on_comboBox_CreaImgFileBitDepth_currentIndexChanged\0"
    "on_lineEdit_CreaImgOutputBmpFileName_textEdited\0"
    "on_pushButton_FWSelectFWBin_clicked\0"
    "on_pushButton_FWAddSplashImage_clicked\0"
    "on_pushButton_FWRemoveSplashImage_clicked\0"
    "on_comboBox_FWSplashImageIndex_currentIndexChanged\0"
    "on_pushButton_FWChangeSplashImage_clicked\0"
    "on_pushButton_FWSelectIniFile_clicked\0"
    "on_pushButton_FWClearSelIniFile_clicked\0"
    "on_pushButton_FWClearFWTag_clicked\0"
    "on_radioButton_FWIllumSelColor_toggled\0"
    "on_radioButton_FWIllumSelMono_toggled\0"
    "on_checkBox_FWIllumSelMonoRedCh_toggled\0"
    "on_checkBox_FWIllumSelMonoGreenCh_toggled\0"
    "on_checkBox_FWIllumSelMonoBlueCh_toggled\0"
    "on_pushButton_FWSplashImageUpload_clicked\0"
    "on_pushButton_FWBuildNewFrmwImage_clicked\0"
    "on_pushButton_FWFileSelect_clicked\0"
    "on_pushButton_FWUpload_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
     123,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  629,    2, 0x08 /* Private */,
       3,    1,  630,    2, 0x08 /* Private */,
       5,    0,  633,    2, 0x08 /* Private */,
       6,    0,  634,    2, 0x08 /* Private */,
       7,    0,  635,    2, 0x08 /* Private */,
       8,    0,  636,    2, 0x08 /* Private */,
       9,    0,  637,    2, 0x08 /* Private */,
      10,    0,  638,    2, 0x08 /* Private */,
      11,    0,  639,    2, 0x08 /* Private */,
      12,    0,  640,    2, 0x08 /* Private */,
      13,    0,  641,    2, 0x08 /* Private */,
      14,    0,  642,    2, 0x08 /* Private */,
      15,    0,  643,    2, 0x08 /* Private */,
      16,    0,  644,    2, 0x08 /* Private */,
      17,    0,  645,    2, 0x08 /* Private */,
      18,    0,  646,    2, 0x08 /* Private */,
      19,    0,  647,    2, 0x08 /* Private */,
      20,    0,  648,    2, 0x08 /* Private */,
      21,    0,  649,    2, 0x08 /* Private */,
      22,    1,  650,    2, 0x08 /* Private */,
      24,    0,  653,    2, 0x08 /* Private */,
      25,    0,  654,    2, 0x08 /* Private */,
      26,    0,  655,    2, 0x08 /* Private */,
      27,    0,  656,    2, 0x08 /* Private */,
      28,    0,  657,    2, 0x08 /* Private */,
      29,    0,  658,    2, 0x08 /* Private */,
      30,    0,  659,    2, 0x08 /* Private */,
      31,    0,  660,    2, 0x08 /* Private */,
      32,    0,  661,    2, 0x08 /* Private */,
      33,    0,  662,    2, 0x08 /* Private */,
      34,    0,  663,    2, 0x08 /* Private */,
      35,    0,  664,    2, 0x08 /* Private */,
      36,    0,  665,    2, 0x08 /* Private */,
      37,    0,  666,    2, 0x08 /* Private */,
      38,    0,  667,    2, 0x08 /* Private */,
      39,    0,  668,    2, 0x08 /* Private */,
      40,    0,  669,    2, 0x08 /* Private */,
      41,    1,  670,    2, 0x08 /* Private */,
      43,    1,  673,    2, 0x08 /* Private */,
      44,    1,  676,    2, 0x08 /* Private */,
      47,    0,  679,    2, 0x08 /* Private */,
      48,    1,  680,    2, 0x08 /* Private */,
      50,    0,  683,    2, 0x08 /* Private */,
      51,    0,  684,    2, 0x08 /* Private */,
      52,    0,  685,    2, 0x08 /* Private */,
      53,    0,  686,    2, 0x08 /* Private */,
      54,    0,  687,    2, 0x08 /* Private */,
      55,    0,  688,    2, 0x08 /* Private */,
      56,    0,  689,    2, 0x08 /* Private */,
      57,    1,  690,    2, 0x08 /* Private */,
      58,    1,  693,    2, 0x08 /* Private */,
      59,    1,  696,    2, 0x08 /* Private */,
      60,    0,  699,    2, 0x08 /* Private */,
      61,    1,  700,    2, 0x08 /* Private */,
      62,    0,  703,    2, 0x08 /* Private */,
      63,    0,  704,    2, 0x08 /* Private */,
      64,    0,  705,    2, 0x08 /* Private */,
      65,    0,  706,    2, 0x08 /* Private */,
      66,    0,  707,    2, 0x08 /* Private */,
      67,    0,  708,    2, 0x08 /* Private */,
      68,    0,  709,    2, 0x08 /* Private */,
      69,    1,  710,    2, 0x08 /* Private */,
      70,    0,  713,    2, 0x08 /* Private */,
      71,    0,  714,    2, 0x08 /* Private */,
      72,    0,  715,    2, 0x08 /* Private */,
      73,    1,  716,    2, 0x08 /* Private */,
      74,    1,  719,    2, 0x08 /* Private */,
      75,    1,  722,    2, 0x08 /* Private */,
      76,    1,  725,    2, 0x08 /* Private */,
      77,    1,  728,    2, 0x08 /* Private */,
      79,    1,  731,    2, 0x08 /* Private */,
      80,    1,  734,    2, 0x08 /* Private */,
      81,    1,  737,    2, 0x08 /* Private */,
      82,    1,  740,    2, 0x08 /* Private */,
      83,    1,  743,    2, 0x08 /* Private */,
      84,    1,  746,    2, 0x08 /* Private */,
      85,    1,  749,    2, 0x08 /* Private */,
      86,    1,  752,    2, 0x08 /* Private */,
      87,    1,  755,    2, 0x08 /* Private */,
      88,    1,  758,    2, 0x08 /* Private */,
      89,    1,  761,    2, 0x08 /* Private */,
      90,    1,  764,    2, 0x08 /* Private */,
      91,    1,  767,    2, 0x08 /* Private */,
      92,    1,  770,    2, 0x08 /* Private */,
      93,    1,  773,    2, 0x08 /* Private */,
      94,    0,  776,    2, 0x08 /* Private */,
      95,    0,  777,    2, 0x08 /* Private */,
      96,    0,  778,    2, 0x08 /* Private */,
      97,    0,  779,    2, 0x08 /* Private */,
      98,    0,  780,    2, 0x08 /* Private */,
      99,    0,  781,    2, 0x08 /* Private */,
     100,    0,  782,    2, 0x08 /* Private */,
     101,    0,  783,    2, 0x08 /* Private */,
     102,    0,  784,    2, 0x08 /* Private */,
     103,    1,  785,    2, 0x08 /* Private */,
     104,    0,  788,    2, 0x08 /* Private */,
     105,    0,  789,    2, 0x08 /* Private */,
     106,    1,  790,    2, 0x08 /* Private */,
     107,    0,  793,    2, 0x08 /* Private */,
     108,    0,  794,    2, 0x08 /* Private */,
     109,    0,  795,    2, 0x08 /* Private */,
     110,    0,  796,    2, 0x08 /* Private */,
     111,    0,  797,    2, 0x08 /* Private */,
     112,    0,  798,    2, 0x08 /* Private */,
     113,    1,  799,    2, 0x08 /* Private */,
     114,    1,  802,    2, 0x08 /* Private */,
     115,    0,  805,    2, 0x08 /* Private */,
     116,    0,  806,    2, 0x08 /* Private */,
     117,    0,  807,    2, 0x08 /* Private */,
     118,    1,  808,    2, 0x08 /* Private */,
     119,    0,  811,    2, 0x08 /* Private */,
     120,    0,  812,    2, 0x08 /* Private */,
     121,    0,  813,    2, 0x08 /* Private */,
     122,    0,  814,    2, 0x08 /* Private */,
     123,    1,  815,    2, 0x08 /* Private */,
     124,    1,  818,    2, 0x08 /* Private */,
     125,    1,  821,    2, 0x08 /* Private */,
     126,    1,  824,    2, 0x08 /* Private */,
     127,    1,  827,    2, 0x08 /* Private */,
     128,    0,  830,    2, 0x08 /* Private */,
     129,    0,  831,    2, 0x08 /* Private */,
     130,    0,  832,    2, 0x08 /* Private */,
     131,    0,  833,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   23,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   42,
    QMetaType::Void, QMetaType::Int,   23,
    QMetaType::Void, 0x80000000 | 45,   46,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QPoint,   49,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   42,
    QMetaType::Void, QMetaType::Int,   23,
    QMetaType::Void, 0x80000000 | 45,   46,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QPoint,   49,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   42,
    QMetaType::Void, QMetaType::Int,   42,
    QMetaType::Void, QMetaType::Int,   42,
    QMetaType::Void, QMetaType::Int,   42,
    QMetaType::Void, QMetaType::Int,   78,
    QMetaType::Void, QMetaType::Int,   78,
    QMetaType::Void, QMetaType::Int,   78,
    QMetaType::Void, QMetaType::Int,   78,
    QMetaType::Void, QMetaType::Int,   42,
    QMetaType::Void, QMetaType::Int,   78,
    QMetaType::Void, QMetaType::Int,   42,
    QMetaType::Void, QMetaType::Int,   78,
    QMetaType::Void, QMetaType::Int,   42,
    QMetaType::Void, QMetaType::Int,   78,
    QMetaType::Void, QMetaType::Int,   42,
    QMetaType::Void, QMetaType::Int,   78,
    QMetaType::Void, QMetaType::Int,   42,
    QMetaType::Void, QMetaType::Int,   78,
    QMetaType::Void, QMetaType::Int,   42,
    QMetaType::Void, QMetaType::Int,   78,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   42,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   23,
    QMetaType::Void, QMetaType::QString,   42,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   23,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    4,
    QMetaType::Void, QMetaType::Bool,    4,
    QMetaType::Void, QMetaType::Bool,    4,
    QMetaType::Void, QMetaType::Bool,    4,
    QMetaType::Void, QMetaType::Bool,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->timerTimeout(); break;
        case 1: _t->on_checkBox_updateStatus_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: _t->on_pushButton_Connect_clicked(); break;
        case 3: _t->on_pushButton_Reset_clicked(); break;
        case 4: _t->on_radioButton_VideoMode_clicked(); break;
        case 5: _t->on_radioButton_SLMode_clicked(); break;
        case 6: _t->on_radioButton_VariableExpSLMode_clicked(); break;
        case 7: _t->on_radioButton_StandbyMode_clicked(); break;
        case 8: _t->on_pushButton_GetLEDConfiguration_clicked(); break;
        case 9: _t->on_pushButton_SetLEDConfiguration_clicked(); break;
        case 10: _t->on_pushButton_GetFlip_clicked(); break;
        case 11: _t->on_pushButton_SetFlip_clicked(); break;
        case 12: _t->on_radioButton_ColorDisplayAuto_clicked(); break;
        case 13: _t->on_radioButton_ColorDisplayManual_clicked(); break;
        case 14: _t->on_pushButton_ApplySolution_clicked(); break;
        case 15: _t->on_pushButton_SaveSolution_clicked(); break;
        case 16: _t->on_pushButton_ApplyDefaultSolution_clicked(); break;
        case 17: _t->on_pushButton_SetPortSource_clicked(); break;
        case 18: _t->on_pushButton_GetPortSource_clicked(); break;
        case 19: _t->on_comboBox_InputSourceList_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 20: _t->on_pushButton_SetPortSwap_clicked(); break;
        case 21: _t->on_pushButton_GetPortSwap_clicked(); break;
        case 22: _t->on_pushButton_SetPortPixelFormat_clicked(); break;
        case 23: _t->on_pushButton_GetPortPixelFormat_clicked(); break;
        case 24: _t->on_pushButton_SetPortClock_clicked(); break;
        case 25: _t->on_pushButton_GetPortClock_clicked(); break;
        case 26: _t->on_pushButton_SetFPDMode_clicked(); break;
        case 27: _t->on_pushButton_GetFPDMode_clicked(); break;
        case 28: _t->on_pushButton_SetTPGColor_clicked(); break;
        case 29: _t->on_pushButton_GetTPGColor_clicked(); break;
        case 30: _t->on_pushButton_SetDisplayConfiguration_clicked(); break;
        case 31: _t->on_pushButton_GetDisplayConfiguration_clicked(); break;
        case 32: _t->on_pushButton_GetVideoSingalInfo_clicked(); break;
        case 33: _t->on_radioButton_PatSeqSrcFrmFlash_clicked(); break;
        case 34: _t->on_radioButton_PatSeqSrcFrmVideoPort_clicked(); break;
        case 35: _t->on_radioButton_PatSeqTrigTypeIntExt_clicked(); break;
        case 36: _t->on_radioButton_PatSeqTrigTypeVSync_clicked(); break;
        case 37: _t->on_spinBox_PatSeqFrameImgIndex_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 38: _t->on_comboBox_PatSeqPatBitDepthSel_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 39: _t->on_listWidget_PatSeqBitPlanes_itemClicked((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 40: _t->on_pushButton_PatSeqAddPatToLut_clicked(); break;
        case 41: _t->on_listWidget_PatSeqLUT_customContextMenuRequested((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 42: _t->on_pushButton_PatSeqSendLUT_clicked(); break;
        case 43: _t->on_pushButton_PatSeqReadLUTFrmHW_clicked(); break;
        case 44: _t->on_pushButton_PatSeqClearLUTFrmGUI_clicked(); break;
        case 45: _t->on_radioButton_VarExpPatSeqSrcFrmFlash_clicked(); break;
        case 46: _t->on_radioButton_VarExpPatSeqSrcFrmVideoPort_clicked(); break;
        case 47: _t->on_radioButton_VarExpPatSeqTrigTypeIntExt_clicked(); break;
        case 48: _t->on_radioButton_VarExpPatSeqTrigTypeVSync_clicked(); break;
        case 49: _t->on_spinBox_VarExpPatSeqFrameImgIndex_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 50: _t->on_comboBox_VarExpPatSeqPatBitDepthSel_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 51: _t->on_listWidget_VarExpPatSeqBitPlanes_itemClicked((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 52: _t->on_pushButton_VarExpPatSeqAddPatToLut_clicked(); break;
        case 53: _t->on_listWidget_VarExpPatSeqLUT_customContextMenuRequested((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 54: _t->on_pushButton_VarExpPatSeqSendLUT_clicked(); break;
        case 55: _t->on_pushButton_VarExpPatSeqReadLUTFrmHW_clicked(); break;
        case 56: _t->on_pushButton_VarExpPatSeqClearLUTFrmGUI_clicked(); break;
        case 57: _t->on_pushButton_ValidatePatSeq_clicked(); break;
        case 58: _t->on_pushButton_PatSeqCtrlStart_clicked(); break;
        case 59: _t->on_pushButton_PatSeqCtrlPause_clicked(); break;
        case 60: _t->on_pushButton_PatSeqCtrlStop_clicked(); break;
        case 61: _t->on_checkBox_PatSeqCtrlGlobalDataInvert_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 62: _t->on_pushButton_GetImgLoadTimingInfo_clicked(); break;
        case 63: _t->on_pushButton_SetTrigConfig_clicked(); break;
        case 64: _t->on_pushButton_GetTrigConfig_clicked(); break;
        case 65: _t->on_spinBox_TrigIn1_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 66: _t->on_spinBox_Trig1OutRDly_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 67: _t->on_spinBox_Trig1OutFDly_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 68: _t->on_spinBox_Trig2OutRDly_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 69: _t->on_horizontalSlider_TrigIn1_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 70: _t->on_horizontalSlider_Trig1OutRDly_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 71: _t->on_horizontalSlider_Trig1OutFDly_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 72: _t->on_horizontalSlider_Trig2OutRDly_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 73: _t->on_spinBox_LedDlyCtrlRedREdgeDly_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 74: _t->on_horizontalSlider_LedDlyCtrlRedREdgeDly_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 75: _t->on_spinBox_LedDlyCtrlRedFEdgeDly_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 76: _t->on_horizontalSlider_LedDlyCtrlRedFEdgeDly_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 77: _t->on_spinBox_LedDlyCtrlGreenREdgeDly_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 78: _t->on_horizontalSlider_LedDlyCtrlGreenREdgeDly_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 79: _t->on_spinBox_LedDlyCtrlGreenFEdgeDly_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 80: _t->on_horizontalSlider_LedDlyCtrlGreenFEdgeDly_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 81: _t->on_spinBox_LedDlyCtrlBlueREdgeDly_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 82: _t->on_horizontalSlider_LedDlyCtrlBlueREdgeDly_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 83: _t->on_spinBox_LedDlyCtrlBlueFEdgeDly_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 84: _t->on_horizontalSlider_LedDlyCtrlBlueFEdgeDly_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 85: _t->on_pushButton_GetLEDDlyCtrlConfig_clicked(); break;
        case 86: _t->on_pushButton_SetLedDlyCtrlConfig_clicked(); break;
        case 87: _t->on_pushButton_SetPWMConfig_clicked(); break;
        case 88: _t->on_pushButton_GetPWMConfig_clicked(); break;
        case 89: _t->on_pushButton_SetPWMCapConfig_clicked(); break;
        case 90: _t->on_pushButton_GetPWMCapConfig_clicked(); break;
        case 91: _t->on_pushButton_PWMCapRead_clicked(); break;
        case 92: _t->on_pushBox_SetGPIOConfig_clicked(); break;
        case 93: _t->on_pushBox_GetGPIOConfig_clicked(); break;
        case 94: _t->on_spinBox_GpClk_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 95: _t->on_pushButton_SetGpClk_clicked(); break;
        case 96: _t->on_pushButton_GetGpClk_clicked(); break;
        case 97: _t->on_checkBox_GPIOEnAltFun_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 98: _t->on_pushButton_i2cWrite_clicked(); break;
        case 99: _t->on_pushButton_i2cRead_clicked(); break;
        case 100: _t->on_pushButton_CreaImgSelectBMPFile_clicked(); break;
        case 101: _t->on_pushButton_CreaImgSelectDestFileName_clicked(); break;
        case 102: _t->on_pushButton_CreaImgClearOutFileContents_clicked(); break;
        case 103: _t->on_pushButton_CreaImgAddToOutFile_clicked(); break;
        case 104: _t->on_comboBox_CreaImgFileBitDepth_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 105: _t->on_lineEdit_CreaImgOutputBmpFileName_textEdited((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 106: _t->on_pushButton_FWSelectFWBin_clicked(); break;
        case 107: _t->on_pushButton_FWAddSplashImage_clicked(); break;
        case 108: _t->on_pushButton_FWRemoveSplashImage_clicked(); break;
        case 109: _t->on_comboBox_FWSplashImageIndex_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 110: _t->on_pushButton_FWChangeSplashImage_clicked(); break;
        case 111: _t->on_pushButton_FWSelectIniFile_clicked(); break;
        case 112: _t->on_pushButton_FWClearSelIniFile_clicked(); break;
        case 113: _t->on_pushButton_FWClearFWTag_clicked(); break;
        case 114: _t->on_radioButton_FWIllumSelColor_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 115: _t->on_radioButton_FWIllumSelMono_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 116: _t->on_checkBox_FWIllumSelMonoRedCh_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 117: _t->on_checkBox_FWIllumSelMonoGreenCh_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 118: _t->on_checkBox_FWIllumSelMonoBlueCh_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 119: _t->on_pushButton_FWSplashImageUpload_clicked(); break;
        case 120: _t->on_pushButton_FWBuildNewFrmwImage_clicked(); break;
        case 121: _t->on_pushButton_FWFileSelect_clicked(); break;
        case 122: _t->on_pushButton_FWUpload_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 123)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 123;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 123)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 123;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
